# Stickman Sync V3 — Premium UI

Android app for the user's workflow:

**Images + Voiceover + TurboScribe timestamp TXT → automatic MP4**

## Input
- ZIP containing `IMAGE 1.png`, `IMAGE 2.png`, etc.
- Voiceover MP3/WAV/M4A
- Timestamp TXT, preferably:

```text
[00:00.000] [IMAGE 1]
[00:04.250] [IMAGE 2]
[00:08.700] [IMAGE 3]
```

or marker mode:

```text
[IMAGE 1]
Narration...

[IMAGE 2]
Narration...
```

## UI
Dark premium mobile UI with project cards, sync modes, aspect ratio controls, timeline preview and export.

## Build
Use the included GitHub Actions workflow or Android Studio.
