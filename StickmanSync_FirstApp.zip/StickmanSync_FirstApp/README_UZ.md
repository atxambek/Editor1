# Stickman Sync — First App

Maqsad: foydalanuvchi tayyor rasmlar + voiceover + timestamp mapping faylini tanlaydi va ilova avtomatik MP4 montaj qiladi.

## Fayl formati

Rasmlar:
- IMAGE 1.png
- IMAGE 2.png
- IMAGE 3.png

Timeline TXT:
```text
00:00 - 00:04.250 | IMAGE 1
00:04.250 - 00:08.700 | IMAGE 2
00:08.700 - 00:12.100 | IMAGE 3
```

Yoki:
```text
[00:00.000] [IMAGE 1]
[00:04.250] [IMAGE 2]
[00:08.700] [IMAGE 3]
```

App vaqtlarni millisekund aniqlikda o‘qiydi va rasmni shu intervalga qo‘yadi.

## Workflow
1. ZIP rasmlar yoki rasmlarni tanlang.
2. Voiceover MP3/WAV tanlang.
3. Timestamp TXT tanlang.
4. Timeline previewni tekshiring.
5. Export MP4 bosing.

## Build
GitHub Actions orqali APK build qilinadi. API key va backend kerak emas.
