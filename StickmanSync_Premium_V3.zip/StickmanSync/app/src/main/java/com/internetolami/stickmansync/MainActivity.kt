package com.internetolami.stickmansync

import android.content.ContentValues
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AlertDialog
import androidx.core.view.setPadding
import androidx.media3.common.MediaItem
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import kotlinx.coroutines.*
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*
import java.util.zip.ZipInputStream

private data class SceneMarker(val number: Int, val text: String, var startMs: Long = 0L, var durationMs: Long = 0L)

class MainActivity : AppCompatActivity() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var imageUris = mutableListOf<Uri>()
    private var audioUri: Uri? = null
    private var scriptText = ""
    private var markers = mutableListOf<SceneMarker>()

    private lateinit var imageInfo: TextView
    private lateinit var audioInfo: TextView
    private lateinit var scriptInfo: TextView
    private lateinit var status: TextView
    private lateinit var timeline: LinearLayout
    private lateinit var exportButton: TextView
    private lateinit var progress: ProgressBar
    private lateinit var modeAuto: TextView
    private lateinit var modeTime: TextView
    private lateinit var ratio169: TextView
    private lateinit var ratio916: TextView
    private var exactMode = false

    private val pickZip = registerForActivityResult(ActivityResultContracts.OpenDocument()) { it?.let(::loadZip) }
    private val pickImages = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) { imageUris = uris.toMutableList(); imageInfo.text = "${uris.size} ta rasm tanlandi"; updateState() }
    }
    private val pickAudio = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { audioUri = it; audioInfo.text = "Voiceover tanlandi • ${fileName(it)}"; updateState() }
    }
    private val pickScript = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> uri?.let(::readTextFile) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(11,13,18)
        window.navigationBarColor = Color.rgb(11,13,18)
        setContentView(buildUi())
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun rounded(color: Int, radius: Int, stroke: Int? = null): android.graphics.drawable.GradientDrawable = android.graphics.drawable.GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius).toFloat(); if (stroke != null) setStroke(dp(1), stroke)
    }
    private fun tv(text: String, size: Float, color: Int, bold: Boolean = false): TextView = TextView(this).apply {
        this.text = text; textSize = size; setTextColor(color); typeface = if (bold) Typeface.create("sans", Typeface.BOLD) else Typeface.create("sans", Typeface.NORMAL)
    }
    private fun add(parent: ViewGroup, child: View, h: Int = ViewGroup.LayoutParams.WRAP_CONTENT, top: Int = 0) {
        parent.addView(child, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, if (h == -1) ViewGroup.LayoutParams.MATCH_PARENT else dp(h)).apply { if (top > 0) topMargin = dp(top) })
    }

    private fun buildUi(): View {
        val scroll = ScrollView(this).apply { setBackgroundColor(Color.rgb(11,13,18)); clipToPadding = false; setPadding(0,0,0,dp(24)) }
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(18), dp(20), dp(20)) }
        scroll.addView(root)

        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val icon = tv("🎬", 28f, Color.WHITE, true).apply { gravity = Gravity.CENTER; background = rounded(Color.rgb(76,38,210), 16) }
        header.addView(icon, LinearLayout.LayoutParams(dp(58), dp(58)))
        val ht = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14),0,0,0) }
        ht.addView(tv("STICKMAN SYNC", 23f, Color.WHITE, true))
        ht.addView(tv("Automatic video maker", 13f, Color.rgb(154,160,174)).apply { setPadding(0,dp(3),0,0) })
        header.addView(ht, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(header)

        root.addView(tv("ZIP + voiceover + timestamps → finished video", 13f, Color.rgb(125,132,148)).apply { setPadding(0,dp(14),0,dp(18)) })

        val project = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16),dp(16),dp(16),dp(16)); background = rounded(Color.rgb(20,23,31), 20) }
        project.addView(tv("NEW PROJECT", 12f, Color.rgb(141,126,255), true))
        project.addView(tv("Build your documentary automatically", 20f, Color.WHITE, true).apply { setPadding(0,dp(6),0,dp(12)) })
        val create = actionButton("＋  START NEW PROJECT", true)
        project.addView(create)
        create.setOnClickListener { pickZip.launch(arrayOf("application/zip", "application/octet-stream")) }
        root.addView(project)

        root.addView(tv("PROJECT FILES", 12f, Color.rgb(125,132,148), true).apply { setPadding(0,dp(24),0,dp(9)) })
        val imageCard = fileCard("①", "IMAGES", "ZIP file or multiple images", "No images selected")
        imageInfo = imageCard.second
        imageCard.first.setOnClickListener { showImageChooser() }
        root.addView(imageCard.first)

        val audioCard = fileCard("②", "VOICEOVER", "MP3 / WAV / M4A", "No voiceover selected")
        audioInfo = audioCard.second
        audioCard.first.setOnClickListener { pickAudio.launch(arrayOf("audio/*")) }
        root.addView(audioCard.first, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(86)).apply { topMargin = dp(10) })

        val scriptCard = fileCard("③", "TIMESTAMPS", "TurboScribe TXT", "No timestamp map selected")
        scriptInfo = scriptCard.second
        scriptCard.first.setOnClickListener { pickScript.launch(arrayOf("text/plain", "text/*")) }
        root.addView(scriptCard.first, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(86)).apply { topMargin = dp(10) })

        root.addView(tv("SYNC MODE", 12f, Color.rgb(125,132,148), true).apply { setPadding(0,dp(22),0,dp(9)) })
        val modes = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        modeAuto = chip("AUTO SYNC")
        modeTime = chip("EXACT TIMESTAMPS")
        modes.addView(modeAuto, LinearLayout.LayoutParams(0,dp(46),1f))
        modes.addView(modeTime, LinearLayout.LayoutParams(0,dp(46),1f).apply { marginStart = dp(8) })
        modeAuto.setOnClickListener { selectMode(true) }; modeTime.setOnClickListener { selectMode(false) }
        root.addView(modes); selectMode(true)

        root.addView(tv("VIDEO FORMAT", 12f, Color.rgb(125,132,148), true).apply { setPadding(0,dp(18),0,dp(9)) })
        val ratios = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        ratio169 = chip("16:9  YouTube"); ratio916 = chip("9:16  Shorts")
        ratios.addView(ratio169, LinearLayout.LayoutParams(0,dp(46),1f)); ratios.addView(ratio916, LinearLayout.LayoutParams(0,dp(46),1f).apply { marginStart = dp(8) })
        ratio169.setOnClickListener { selectRatio(true) }; ratio916.setOnClickListener { selectRatio(false) }
        root.addView(ratios); selectRatio(true)

        val tlTitle = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0,dp(24),0,dp(9)) }
        tlTitle.addView(tv("TIMELINE", 12f, Color.rgb(125,132,148), true), LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1f))
        tlTitle.addView(tv("LIVE PREVIEW", 11f, Color.rgb(75,205,145), true).apply { background = rounded(Color.rgb(18,55,43), 20); setPadding(dp(10),dp(5),dp(10),dp(5)) })
        root.addView(tlTitle)
        timeline = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12),dp(12),dp(12),dp(12)); background = rounded(Color.rgb(16,19,26), 18) }
        timeline.addView(tv("Choose your files to generate the timeline.", 13f, Color.rgb(123,130,144)).apply { setPadding(dp(4),dp(14),dp(4),dp(14)) })
        root.addView(timeline)

        status = tv("Ready when you are.", 13f, Color.rgb(145,151,164)).apply { setPadding(dp(2),dp(12),dp(2),dp(4)) }
        root.addView(status)
        progress = ProgressBar(this).apply { visibility = View.GONE; indeterminateTintList = android.content.res.ColorStateList.valueOf(Color.rgb(93,78,255)) }
        root.addView(progress, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(4)).apply { topMargin = dp(4) })
        exportButton = actionButton("EXPORT VIDEO", true).apply { alpha = .45f; isClickable = false }
        root.addView(exportButton, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(56)).apply { topMargin = dp(12) })
        exportButton.setOnClickListener { analyzeAndExport() }
        return scroll
    }

    private fun fileCard(num: String, title: String, subtitle: String, initial: String): Pair<LinearLayout, TextView> {
        val card = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(14),dp(12),dp(14),dp(12)); background = rounded(Color.rgb(20,23,31), 16, Color.rgb(38,42,53)) }
        val badge = tv(num, 13f, Color.WHITE, true).apply { gravity = Gravity.CENTER; background = rounded(Color.rgb(58,62,76), 12) }
        card.addView(badge, LinearLayout.LayoutParams(dp(40),dp(40)))
        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12),0,dp(8),0) }
        body.addView(tv(title, 14f, Color.WHITE, true))
        body.addView(tv(subtitle, 11f, Color.rgb(126,133,148)).apply { setPadding(0,dp(2),0,dp(3)) })
        val info = tv(initial, 11f, Color.rgb(86,190,148))
        body.addView(info)
        card.addView(body, LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1f))
        card.addView(tv("›", 28f, Color.rgb(101,107,121), false))
        return card to info
    }

    private fun actionButton(label: String, primary: Boolean): TextView = tv(label, 14f, Color.WHITE, true).apply {
        gravity = Gravity.CENTER; background = rounded(if (primary) Color.rgb(91,73,238) else Color.rgb(35,39,49), 16)
    }
    private fun chip(label: String): TextView = tv(label, 12f, Color.rgb(178,183,195), true).apply { gravity = Gravity.CENTER; background = rounded(Color.rgb(25,29,38), 13, Color.rgb(47,51,64)) }
    private fun selectMode(auto: Boolean) { exactMode = !auto; modeAuto.background = rounded(if (auto) Color.rgb(70,56,190) else Color.rgb(25,29,38), 13, if (auto) Color.rgb(119,105,255) else Color.rgb(47,51,64)); modeTime.background = rounded(if (!auto) Color.rgb(70,56,190) else Color.rgb(25,29,38), 13, if (!auto) Color.rgb(119,105,255) else Color.rgb(47,51,64)) }
    private fun selectRatio(wide: Boolean) { ratio169.background = rounded(if (wide) Color.rgb(70,56,190) else Color.rgb(25,29,38), 13, if (wide) Color.rgb(119,105,255) else Color.rgb(47,51,64)); ratio916.background = rounded(if (!wide) Color.rgb(70,56,190) else Color.rgb(25,29,38), 13, if (!wide) Color.rgb(119,105,255) else Color.rgb(47,51,64)) }

    private fun showImageChooser() {
        AlertDialog.Builder(this).setTitle("Choose images").setItems(arrayOf("ZIP file", "Select images")) { _, which ->
            if (which == 0) pickZip.launch(arrayOf("application/zip", "application/octet-stream")) else pickImages.launch(arrayOf("image/*"))
        }.show()
    }

    private fun loadZip(uri: Uri) {
        scope.launch(Dispatchers.IO) {
            try {
                val dir = File(cacheDir, "stickman_zip_${System.currentTimeMillis()}").apply { mkdirs() }
                val found = mutableListOf<Pair<Int, File>>()
                contentResolver.openInputStream(uri).use { input -> requireNotNull(input) { "ZIP could not be opened" }; ZipInputStream(input).use { zis ->
                    while (true) { val e = zis.nextEntry ?: break; if (e.isDirectory) continue; val name = e.name.substringAfterLast('/'); val match = Regex("(?i)^image[ _-]?(\\d+)\\.(png|jpg|jpeg|webp)$").find(name) ?: continue; val file = File(dir, name); FileOutputStream(file).use { out -> zis.copyTo(out) }; found += match.groupValues[1].toInt() to file }
                } }
                val sorted = found.sortedBy { it.first }; require(sorted.isNotEmpty()) { "No IMAGE 1.png files found" }
                withContext(Dispatchers.Main) { imageUris = sorted.map { Uri.fromFile(it.second) }.toMutableList(); imageInfo.text = "${sorted.size} ta rasm • ${sorted.first().first}–${sorted.last().first}"; updateState() }
            } catch (e: Exception) { withContext(Dispatchers.Main) { status.text = "ZIP error: ${e.message}" } }
        }
    }

    private fun readTextFile(uri: Uri) {
        try { scriptText = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: ""; markers = parseMarkers(scriptText).toMutableList(); scriptInfo.text = "${markers.size} ta marker topildi"; status.text = if (markers.isEmpty()) "Marker topilmadi" else "Timestamp map tayyor ✓"; renderTimeline(); updateState() }
        catch (e: Exception) { status.text = "TXT error: ${e.message}" }
    }

    private fun parseMarkers(text: String): List<SceneMarker> {
        val ts = Regex("(?m)^\\s*\\[(\\d{1,2}):(\\d{2})(?:\\.(\\d{1,3}))?\\]\\s*\\[IMAGE\\s*[_-]?\\s*(\\d+)\\]", RegexOption.IGNORE_CASE)
        val timed = ts.findAll(text).toList()
        if (timed.isNotEmpty()) return timed.mapIndexed { i, m ->
            val start = m.groupValues[1].toLong()*60000 + m.groupValues[2].toLong()*1000 + m.groupValues[3].padEnd(3,'0').take(3).toLong()
            val end = if (i+1 < timed.size) { val n=timed[i+1]; n.groupValues[1].toLong()*60000+n.groupValues[2].toLong()*1000+n.groupValues[3].padEnd(3,'0').take(3).toLong() } else 0L
            SceneMarker(m.groupValues[4].toInt(), "", start, if (end>0) end-start else 0)
        }.sortedBy { it.startMs }
        val regex = Regex("(?m)^\\s*\\[IMAGE\\s*[_-]?\\s*(\\d+)\\]\\s*$", RegexOption.IGNORE_CASE)
        val matches = regex.findAll(text).toList()
        return matches.mapIndexed { i,m -> val next=if(i+1<matches.size) matches[i+1].range.first else text.length; SceneMarker(m.groupValues[1].toInt(), text.substring(m.range.last+1,next).trim()) }.sortedBy { it.number }
    }

    private fun updateState() {
        val ready = imageUris.isNotEmpty() && audioUri != null && markers.isNotEmpty()
        exportButton.isClickable = ready; exportButton.alpha = if (ready) 1f else .45f
        if (ready) { status.text = "Project ready • ${markers.size} scenes"; renderTimeline() }
    }

    private fun renderTimeline() {
        timeline.removeAllViews()
        if (markers.isEmpty()) { timeline.addView(tv("Choose a timestamp TXT to preview scenes.",13f,Color.rgb(123,130,144)).apply{setPadding(dp(4),dp(14),dp(4),dp(14))}); return }
        markers.take(12).forEachIndexed { i,m ->
            val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(6),dp(7),dp(6),dp(7))}
            val n=tv(String.format("%02d",m.number),11f,Color.WHITE,true).apply{gravity=Gravity.CENTER;background=rounded(Color.rgb(54,59,72),10)}
            row.addView(n,LinearLayout.LayoutParams(dp(38),dp(38)))
            val b=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(10),0,0,0)}
            b.addView(tv("IMAGE ${m.number}",13f,Color.WHITE,true))
            val time=if(m.durationMs>0) formatMs(m.startMs)+"  •  "+String.format(Locale.US,"%.2fs",m.durationMs/1000.0) else "Timing pending"
            b.addView(tv(time,11f,Color.rgb(102,190,157)).apply{setPadding(0,dp(3),0,0)})
            row.addView(b,LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1f)); timeline.addView(row)
            if(i<minOf(11,markers.size-1)) timeline.addView(View(this).apply{setBackgroundColor(Color.rgb(34,38,48))},LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,1))
        }
        if(markers.size>12) timeline.addView(tv("+ ${markers.size-12} more scenes",11f,Color.rgb(120,126,140)).apply{setPadding(dp(54),dp(9),0,0)})
    }
    private fun formatMs(ms:Long)=String.format(Locale.US,"%02d:%02d",ms/60000,(ms/1000)%60)
    private fun fileName(uri:Uri)=uri.lastPathSegment?.substringAfterLast('/')?.take(24) ?: "audio"

    private fun analyzeAndExport() {
        val audio=audioUri ?: return; exportButton.isClickable=false; progress.visibility=View.VISIBLE; status.text="Analyzing voiceover…"
        scope.launch { try {
            val duration=withContext(Dispatchers.IO){MediaUtils.getDurationMs(this@MainActivity,audio)}; require(duration>0){"Voiceover duration not found"}
            val ordered=markers.sortedBy{it.startMs}.toMutableList()
            val exact=exactMode && markers.any{it.startMs>0 || it.durationMs>0}
            if(!exact){ val total=ordered.sumOf{wordCount(it.text)}.coerceAtLeast(1); var cursor=0L; ordered.forEach{it.startMs=cursor;it.durationMs=(duration.toDouble()*wordCount(it.text)/total).toLong().coerceAtLeast(1);cursor+=it.durationMs}; if(ordered.isNotEmpty()) ordered.last().durationMs=(ordered.last().durationMs+(duration-cursor)).coerceAtLeast(1)}
            markers=ordered; renderTimeline(); status.text="Rendering video…"; exportWithTimeline(audio,ordered,duration)
        } catch(e:Exception){progress.visibility=View.GONE;exportButton.isClickable=true;status.text="Error: ${e.message}"} }
    }
    private fun wordCount(s:String)=s.trim().split(Regex("\\s+")).count{it.isNotBlank()}.coerceAtLeast(1)

    private suspend fun exportWithTimeline(audio:Uri, scenes:List<SceneMarker>, total:Long){
        val items=mutableListOf<EditedMediaItem>()
        for(s in scenes){ val u=imageUris.firstOrNull{it.toString().substringAfterLast('/').substringBeforeLast('.').replace("_"," ").equals("image ${s.number}",true)} ?: imageUris.getOrNull(s.number-1) ?: continue; items+=EditedMediaItem.Builder(MediaItem.Builder().setUri(u).setImageDurationMs(s.durationMs.coerceAtLeast(1)).build()).build() }
        require(items.isNotEmpty()){"No images matched"}
        val video=EditedMediaItemSequence(items); val aud=EditedMediaItemSequence(listOf(EditedMediaItem.Builder(MediaItem.fromUri(audio)).build())); val comp=Composition.Builder(video,aud).build(); val out=withContext(Dispatchers.IO){MediaUtils.createOutput(this@MainActivity)}
        val transformer=Transformer.Builder(this@MainActivity).setVideoMimeType("video/avc").build()
        suspendCancellableCoroutine<Unit>{ cont-> transformer.addListener(object:Transformer.Listener{override fun onCompleted(c:Composition,r:ExportResult){if(cont.isActive)cont.resume(Unit){}};override fun onError(c:Composition,r:ExportResult,e:androidx.media3.transformer.ExportException){if(cont.isActive)cont.resumeWith(Result.failure(e))}});transformer.start(comp,out.toString()) }
        withContext(Dispatchers.Main){progress.visibility=View.GONE;exportButton.isClickable=true;status.text="Video exported ✓  •  Movies/StickmanSync";Toast.makeText(this@MainActivity,"Video tayyor ✓",Toast.LENGTH_LONG).show()}
    }
    override fun onDestroy(){scope.cancel();super.onDestroy()}
}

object MediaUtils{
    fun getDurationMs(context:Context,uri:Uri):Long{val r=android.media.MediaMetadataRetriever();return try{r.setDataSource(context,uri);r.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()?:0L}finally{r.release()}}
    fun createOutput(context:Context):Uri{val name="StickmanSync_"+SimpleDateFormat("yyyyMMdd_HHmmss",Locale.US).format(Date())+".mp4";val v=ContentValues().apply{put(MediaStore.Video.Media.DISPLAY_NAME,name);put(MediaStore.Video.Media.MIME_TYPE,"video/mp4");put(MediaStore.Video.Media.RELATIVE_PATH,"Movies/StickmanSync")};return context.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI,v)?:error("Output file failed")}
}
