package com.internetolami.stickmansync

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.setPadding
import androidx.media3.common.MediaItem
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import kotlinx.coroutines.*
import java.io.File
import java.io.FileOutputStream
import java.util.Locale
import java.util.zip.ZipInputStream

private data class TimelineItem(val imageNumber: Int, val startMs: Long, val endMs: Long, val label: String = "") {
    val durationMs get() = (endMs - startMs).coerceAtLeast(1L)
}

class MainActivity : AppCompatActivity() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val imageMap = linkedMapOf<Int, Uri>()
    private var audioUri: Uri? = null
    private var timeline = mutableListOf<TimelineItem>()

    private lateinit var imagesInfo: TextView
    private lateinit var audioInfo: TextView
    private lateinit var timelineInfo: TextView
    private lateinit var status: TextView
    private lateinit var exportButton: Button
    private lateinit var progress: ProgressBar

    private val pickZip = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> uri?.let { extractZip(it) } }
    private val pickImages = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) loadImages(uris)
    }
    private val pickAudio = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { audioUri = it; audioInfo.text = "Voiceover: ${it.lastPathSegment ?: "audio"}"; status.text = "Voiceover tayyor ✓"; updateButton() }
    }
    private val pickTimeline = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { readTimeline(it) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(buildUi())
    }

    private fun buildUi(): View {
        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28)
            setBackgroundColor(0xFFF6F7F9.toInt())
        }
        scroll.addView(root)

        root.addView(TextView(this).apply {
            text = "STICKMAN SYNC"
            textSize = 30f
            setTextColor(0xFF101318.toInt())
            setPadding(0, 20, 0, 4)
        })
        root.addView(TextView(this).apply {
            text = "Voiceover + timestamps + images → automatic video"
            textSize = 15f
            setTextColor(0xFF5D6470.toInt())
            setPadding(0, 0, 0, 24)
        })

        root.addView(section("1. RASMLAR"))
        root.addView(button("ZIP ichidan IMAGE 1, IMAGE 2... tanlash") { pickZip.launch(arrayOf("application/zip", "application/octet-stream")) })
        root.addView(button("Yoki rasmlarni alohida tanlash") { pickImages.launch(arrayOf("image/*")) })
        imagesInfo = info("Hali rasmlar tanlanmagan")
        root.addView(imagesInfo)

        root.addView(section("2. VOICEOVER"))
        root.addView(button("MP3 / WAV tanlash") { pickAudio.launch(arrayOf("audio/*")) })
        audioInfo = info("Hali voiceover tanlanmagan")
        root.addView(audioInfo)

        root.addView(section("3. TIMESTAMP MAP"))
        root.addView(TextView(this).apply {
            text = "TurboScribe vaqtlarini mana shu formatda saqlang:"
            textSize = 13f
            setTextColor(0xFF5D6470.toInt())
        })
        root.addView(TextView(this).apply {
            text = "00:00 - 00:04.250 | IMAGE 1\n00:04.250 - 00:08.700 | IMAGE 2"
            textSize = 13f
            setTextColor(0xFF20242A.toInt())
            setPadding(12, 12, 12, 12)
            setBackgroundColor(0xFFFFFFFF.toInt())
        })
        root.addView(button("TIMELINE TXT tanlash") { pickTimeline.launch(arrayOf("text/plain", "text/*")) })
        timelineInfo = info("Hali timeline tanlanmagan")
        root.addView(timelineInfo)

        root.addView(section("4. PREVIEW"))
        val previewBox = TextView(this).apply {
            text = "Timeline preview shu yerda chiqadi."
            textSize = 14f
            setTextColor(0xFF20242A.toInt())
            setPadding(14, 14, 14, 14)
            setBackgroundColor(0xFFFFFFFF.toInt())
        }
        root.addView(previewBox)

        root.addView(section("5. EXPORT"))
        exportButton = button("VIDEO YARATISH") { exportVideo(previewBox) }
        exportButton.isEnabled = false
        root.addView(exportButton)
        progress = ProgressBar(this).apply { visibility = View.GONE }
        root.addView(progress)
        status = info("3 ta faylni tanlang: rasmlar + voiceover + timestamp TXT")
        status.setPadding(0, 18, 0, 30)
        root.addView(status)
        return scroll
    }

    private fun section(title: String) = TextView(this).apply {
        text = title
        textSize = 18f
        setTextColor(0xFF11151A.toInt())
        setPadding(0, 24, 0, 8)
    }

    private fun button(textValue: String, action: () -> Unit) = Button(this).apply {
        text = textValue
        setOnClickListener { action() }
    }

    private fun info(textValue: String) = TextView(this).apply {
        text = textValue
        textSize = 14f
        setTextColor(0xFF5D6470.toInt())
        setPadding(0, 6, 0, 8)
    }

    private fun loadImages(uris: List<Uri>) {
        imageMap.clear()
        val numberRegex = Regex("(?i)(?:image|img)[ _-]?(\\d+)")
        for (uri in uris) {
            val name = uri.lastPathSegment?.substringAfterLast('/') ?: continue
            val match = numberRegex.find(name) ?: continue
            imageMap[match.groupValues[1].toInt()] = uri
        }
        imagesInfo.text = if (imageMap.isEmpty()) "IMAGE 1, IMAGE 2 kabi nomlangan rasmlar topilmadi" else "${imageMap.size} ta rasm tayyor ✓"
        status.text = if (imageMap.isEmpty()) "Rasm nomlarini IMAGE 1, IMAGE 2... qiling" else "Rasmlar tayyor ✓"
        updateButton()
    }

    private fun extractZip(uri: Uri) {
        status.text = "ZIP ochilmoqda…"
        scope.launch(Dispatchers.IO) {
            try {
                val dir = File(cacheDir, "images_${System.currentTimeMillis()}").apply { mkdirs() }
                val temp = linkedMapOf<Int, Uri>()
                contentResolver.openInputStream(uri).use { input ->
                    requireNotNull(input) { "ZIP ochilmadi" }
                    ZipInputStream(input).use { zis ->
                        while (true) {
                            val entry = zis.nextEntry ?: break
                            if (entry.isDirectory) continue
                            val name = entry.name.substringAfterLast('/')
                            val match = Regex("(?i)^(?:image|img)[ _-]?(\\d+)\\.(png|jpg|jpeg|webp)$").find(name) ?: continue
                            val file = File(dir, name)
                            FileOutputStream(file).use { out -> zis.copyTo(out) }
                            temp[match.groupValues[1].toInt()] = Uri.fromFile(file)
                        }
                    }
                }
                withContext(Dispatchers.Main) {
                    imageMap.clear(); imageMap.putAll(temp.toSortedMap())
                    imagesInfo.text = "ZIP: ${imageMap.size} ta rasm tayyor ✓"
                    status.text = if (imageMap.isEmpty()) "ZIP ichida IMAGE 1.png kabi fayllar topilmadi" else "ZIP tayyor ✓"
                    updateButton()
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) { status.text = "ZIP xatosi: ${e.message}" }
            }
        }
    }

    private fun readTimeline(uri: Uri) {
        try {
            val text = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: ""
            val parsed = parseTimeline(text)
            require(parsed.isNotEmpty()) { "Timestamp topilmadi" }
            timeline = parsed.toMutableList()
            timelineInfo.text = "${timeline.size} ta timeline segment topildi ✓"
            status.text = "Timeline tayyor ✓"
            updateButton()
        } catch (e: Exception) {
            timelineInfo.text = "Timeline o‘qilmadi"
            status.text = "TXT xatosi: ${e.message}"
        }
    }

    private fun parseTimeline(text: String): List<TimelineItem> {
        val rangeRegex = Regex("(?mi)^\\s*(\\d{1,2}):(\\d{2})(?:[.:](\\d{1,3}))?\\s*-\\s*(\\d{1,2}):(\\d{2})(?:[.:](\\d{1,3}))?\\s*\\|\\s*(?:\\[)?(?:IMAGE|IMG)[ _-]?(\\d+)(?:\\])?")
        val results = rangeRegex.findAll(text).mapNotNull { m ->
            val start = parseClock(m.groupValues[1], m.groupValues[2], m.groupValues[3])
            val end = parseClock(m.groupValues[4], m.groupValues[5], m.groupValues[6])
            val image = m.groupValues[7].toIntOrNull() ?: return@mapNotNull null
            if (end <= start) return@mapNotNull null
            TimelineItem(image, start, end)
        }.toList()
        if (results.isNotEmpty()) return results

        val pointRegex = Regex("(?mi)^\\s*\\[(\\d{1,2}):(\\d{2})(?:[.:](\\d{1,3}))?\\]\\s*\\[?(?:IMAGE|IMG)[ _-]?(\\d+)\\]?")
        val points = pointRegex.findAll(text).mapNotNull { m ->
            val start = parseClock(m.groupValues[1], m.groupValues[2], m.groupValues[3])
            val image = m.groupValues[4].toIntOrNull() ?: return@mapNotNull null
            start to image
        }.toList()
        val last = points.lastOrNull()?.first ?: 0L
        return points.mapIndexed { i, p ->
            val end = if (i + 1 < points.size) points[i + 1].first else last + 1L
            TimelineItem(p.second, p.first, end)
        }.filter { it.endMs > it.startMs }
    }

    private fun parseClock(min: String, sec: String, fraction: String): Long {
        val frac = fraction.padEnd(3, '0').take(3).toLongOrNull() ?: 0L
        return min.toLong() * 60_000L + sec.toLong() * 1_000L + frac
    }

    private fun updateButton() {
        exportButton.isEnabled = imageMap.isNotEmpty() && audioUri != null && timeline.isNotEmpty()
    }

    private fun exportVideo(preview: TextView) {
        val audio = audioUri ?: return
        exportButton.isEnabled = false
        progress.visibility = View.VISIBLE
        status.text = "Timeline tekshirilmoqda…"
        val usable = timeline.filter { imageMap.containsKey(it.imageNumber) }
        if (usable.isEmpty()) {
            status.text = "Timeline'dagi IMAGE raqamlari rasmlar bilan mos emas"
            progress.visibility = View.GONE
            exportButton.isEnabled = true
            return
        }
        preview.text = usable.joinToString("\n\n") {
            "IMAGE ${it.imageNumber}\n${formatMs(it.startMs)} → ${formatMs(it.endMs)}  (${String.format(Locale.US, "%.2fs", it.durationMs / 1000.0)})"
        }
        scope.launch {
            try {
                val audioDuration = withContext(Dispatchers.IO) { MediaUtils.getDurationMs(this@MainActivity, audio) }
                require(audioDuration > 0) { "Voiceover davomiyligi aniqlanmadi" }
                val clamped = usable.map { it.copy(endMs = minOf(it.endMs, audioDuration)) }.filter { it.endMs > it.startMs }
                require(clamped.isNotEmpty()) { "Audio bilan mos timeline yo‘q" }
                withContext(Dispatchers.Main) { status.text = "Video render qilinmoqda…" }
                exportWithTimeline(audio, clamped)
            } catch (e: Exception) {
                progress.visibility = View.GONE
                exportButton.isEnabled = true
                status.text = "Export xatosi: ${e.message}"
            }
        }
    }

    private suspend fun exportWithTimeline(audio: Uri, scenes: List<TimelineItem>) {
        val items = scenes.map { scene ->
            val uri = imageMap[scene.imageNumber] ?: error("IMAGE ${scene.imageNumber} topilmadi")
            val mediaItem = MediaItem.Builder().setUri(uri).setImageDurationMs(scene.durationMs).build()
            EditedMediaItem.Builder(mediaItem).build()
        }
        val videoSequence = EditedMediaItemSequence(items)
        val audioSequence = EditedMediaItemSequence(listOf(EditedMediaItem.Builder(MediaItem.fromUri(audio)).build()))
        val composition = Composition.Builder(videoSequence, audioSequence).build()
        val output = withContext(Dispatchers.IO) { MediaUtils.createOutput(this@MainActivity) }
        val transformer = Transformer.Builder(this@MainActivity).setVideoMimeType("video/avc").build()
        suspendCancellableCoroutine<Unit> { cont ->
            transformer.addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    if (cont.isActive) cont.resume(Unit) {}
                }
                override fun onError(composition: Composition, exportResult: ExportResult, exportException: androidx.media3.transformer.ExportException) {
                    if (cont.isActive) cont.resumeWith(Result.failure(exportException))
                }
            })
            transformer.start(composition, output.toString())
        }
        withContext(Dispatchers.Main) {
            progress.visibility = View.GONE
            exportButton.isEnabled = true
            status.text = "TAYYOR ✓ Movies/StickmanSync papkasiga saqlandi"
            Toast.makeText(this@MainActivity, "Video tayyor!", Toast.LENGTH_LONG).show()
        }
    }

    private fun formatMs(ms: Long): String = String.format(Locale.US, "%02d:%05.2f", ms / 60_000, (ms % 60_000) / 1000.0)

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }
}

object MediaUtils {
    fun getDurationMs(context: Context, uri: Uri): Long {
        val retriever = android.media.MediaMetadataRetriever()
        return try {
            retriever.setDataSource(context, uri)
            retriever.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        } finally { retriever.release() }
    }

    fun createOutput(context: Context): Uri {
        val name = "StickmanSync_${System.currentTimeMillis()}.mp4"
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, name)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/StickmanSync")
        }
        return context.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
            ?: error("Output fayl yaratilmadi")
    }
}
